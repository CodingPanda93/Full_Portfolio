var mathlib = require('./mathlib')();
mathlib.add(7,6);
mathlib.multiply(5,2);
mathlib.square(6);
mathlib.random(3,40);
